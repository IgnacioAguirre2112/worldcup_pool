# Quiniela Mundial FIFA 2026

Aplicación Streamlit para administrar una competencia de pronósticos del Mundial FIFA 2026.

## Instalación local

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Estructura

- `app.py`: dashboard principal e ingreso por nombre.
- `database.py`: conexión SQLite, helpers y ranking.
- `models.py`: modelos SQLAlchemy.
- `scoring.py`: reglas de puntaje.
- `pages/Pronosticos.py`: pronósticos y bonus.
- `pages/Ranking.py`: ranking con autorefresh y Excel.
- `pages/Estadisticas.py`: métricas y gráficos Plotly.
- `pages/Admin.py`: administración de fixture, resultados y exportaciones.

## Streamlit Community Cloud

1. Sube este proyecto a GitHub.
2. En Streamlit Community Cloud, crea una app apuntando a `app.py`.
3. Configura secrets:

```toml
ADMIN_USER="admin"
ADMIN_PASSWORD="password"
```

## Fixture CSV

Formato esperado:

```csv
fecha_hora,fase,local,visita
2026-06-11 20:00,Grupos,México,Canadá
```

Las fechas se interpretan en UTC.
