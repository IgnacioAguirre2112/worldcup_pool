from __future__ import annotations
from datetime import datetime
from pathlib import Path
from sqlalchemy import create_engine, select, func
from sqlalchemy.orm import sessionmaker
from models import Base, Usuario, Partido, Pronostico, PronosticoBonus
from scoring import calcular_puntaje

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "mundial2026.db"
DB_PATH.parent.mkdir(exist_ok=True)
engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

FASES = ["Grupos", "Dieciseisavos", "Octavos", "Cuartos", "Semifinal", "Tercer Lugar", "Final"]


def init_db() -> None:
    Base.metadata.create_all(engine)


def get_or_create_user(nombre: str) -> Usuario:
    nombre = " ".join(nombre.strip().split())[:80]
    if not nombre:
        raise ValueError("Ingresa un nombre válido")
    with SessionLocal() as db:
        user = db.scalar(select(Usuario).where(func.lower(Usuario.nombre) == nombre.lower()))
        if user:
            return user
        user = Usuario(nombre=nombre)
        db.add(user)
        db.commit()
        return user


def partido_bloqueado(partido: Partido) -> bool:
    return datetime.utcnow() >= partido.fecha_hora_utc


def guardar_pronostico(usuario_id: int, partido_id: int, gl: int, gv: int) -> None:
    with SessionLocal() as db:
        partido = db.get(Partido, partido_id)
        if not partido or partido_bloqueado(partido):
            raise ValueError("Pronóstico cerrado")
        p = db.scalar(select(Pronostico).where(Pronostico.usuario_id == usuario_id, Pronostico.partido_id == partido_id))
        if p:
            p.goles_local_pronosticado = gl
            p.goles_visita_pronosticado = gv
            p.fecha_ingreso = datetime.utcnow()
        else:
            db.add(Pronostico(usuario_id=usuario_id, partido_id=partido_id, goles_local_pronosticado=gl, goles_visita_pronosticado=gv))
        db.commit()


def primera_fecha_mundial() -> datetime | None:
    with SessionLocal() as db:
        return db.scalar(select(func.min(Partido.fecha_hora_utc)))


def bonus_bloqueado() -> bool:
    primera = primera_fecha_mundial()
    return bool(primera and datetime.utcnow() >= primera)


def ranking_dataframe():
    import pandas as pd
    rows = []
    with SessionLocal() as db:
        usuarios = db.scalars(select(Usuario).order_by(Usuario.nombre)).all()
        for u in usuarios:
            total = exactos = parciales = bonus = 0
            for p in u.pronosticos:
                if p.partido.resultado_oficial_cargado:
                    puntos, tipo = calcular_puntaje(p.goles_local_pronosticado, p.goles_visita_pronosticado, p.partido.goles_local, p.partido.goles_visita)
                    total += puntos
                    exactos += tipo == "exacto"
                    parciales += tipo == "parcial"
            # Bonus manual simple: queda listo para comparar cuando se carguen campeon/subcampeon/etc.
            total += bonus
            rows.append({"Participante": u.nombre, "Exactos": exactos, "Parciales": parciales, "Bonus": bonus, "Total": total})
    df = pd.DataFrame(rows, columns=["Participante", "Exactos", "Parciales", "Bonus", "Total"])
    if not df.empty:
        df = df.sort_values(["Total", "Exactos", "Parciales"], ascending=False).reset_index(drop=True)
        df.insert(0, "Posición", range(1, len(df) + 1))
    return df
