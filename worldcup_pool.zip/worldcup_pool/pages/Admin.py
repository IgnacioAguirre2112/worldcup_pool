from datetime import datetime, date, time
from io import BytesIO
import pandas as pd
import streamlit as st
from sqlalchemy import select
from database import SessionLocal, FASES, init_db
from models import Partido, Usuario, Pronostico

st.set_page_config(page_title="Admin", page_icon="🛠️", layout="wide")
st.title("🛠️ Panel Administrador")
init_db()

user = st.text_input("Usuario admin")
password = st.text_input("Password", type="password")
if user != st.secrets.get("ADMIN_USER", "admin") or password != st.secrets.get("ADMIN_PASSWORD", "password"):
    st.warning("Ingresa credenciales de administrador.")
    st.stop()

st.success("Acceso concedido")

tab1, tab2, tab3, tab4 = st.tabs(["Partidos", "Resultados", "Fixture CSV", "Exportaciones/Reinicio"])

with tab1:
    st.subheader("Crear partido")
    col1, col2 = st.columns(2)
    fecha = col1.date_input("Fecha", value=date(2026, 6, 11))
    hora = col2.time_input("Hora UTC", value=time(20, 0))
    fase = st.selectbox("Fase", FASES)
    local = st.text_input("Equipo local")
    visita = st.text_input("Equipo visita")
    if st.button("Crear partido") and local and visita:
        with SessionLocal() as db:
            db.add(Partido(fecha_hora_utc=datetime.combine(fecha, hora), fase=fase, equipo_local=local.strip(), equipo_visita=visita.strip()))
            db.commit()
        st.success("Partido creado")

    with SessionLocal() as db:
        partidos = db.scalars(select(Partido).order_by(Partido.fecha_hora_utc)).all()
    for p in partidos:
        with st.expander(f"{p.id} · {p.equipo_local} vs {p.equipo_visita}"):
            if st.button("Eliminar", key=f"del_{p.id}"):
                with SessionLocal() as db:
                    obj = db.get(Partido, p.id)
                    db.delete(obj)
                    db.commit()
                st.rerun()

with tab2:
    with SessionLocal() as db:
        partidos = db.scalars(select(Partido).order_by(Partido.fecha_hora_utc)).all()
    for p in partidos:
        with st.container(border=True):
            st.write(f"{p.equipo_local} vs {p.equipo_visita}")
            gl = st.number_input("Goles local", 0, 30, value=p.goles_local or 0, key=f"rgl_{p.id}")
            gv = st.number_input("Goles visita", 0, 30, value=p.goles_visita or 0, key=f"rgv_{p.id}")
            if st.button("Guardar resultado", key=f"res_{p.id}"):
                with SessionLocal() as db:
                    obj = db.get(Partido, p.id)
                    obj.goles_local = int(gl)
                    obj.goles_visita = int(gv)
                    obj.resultado_oficial_cargado = True
                    db.commit()
                st.success("Resultado cargado. El ranking se recalcula al consultar.")

with tab3:
    archivo = st.file_uploader("Importar fixture.csv", type=["csv"])
    if archivo and st.button("Importar"):
        df = pd.read_csv(archivo)
        with SessionLocal() as db:
            for _, row in df.iterrows():
                db.add(Partido(fecha_hora_utc=pd.to_datetime(row["fecha_hora"]).to_pydatetime(), fase=row["fase"], equipo_local=row["local"], equipo_visita=row["visita"]))
            db.commit()
        st.success("Fixture importado")

with tab4:
    with SessionLocal() as db:
        partidos_df = pd.DataFrame([{c.name: getattr(p, c.name) for c in Partido.__table__.columns} for p in db.scalars(select(Partido)).all()])
        usuarios_df = pd.DataFrame([{c.name: getattr(u, c.name) for c in Usuario.__table__.columns} for u in db.scalars(select(Usuario)).all()])
        pron_df = pd.DataFrame([{c.name: getattr(p, c.name) for c in Pronostico.__table__.columns} for p in db.scalars(select(Pronostico)).all()])
    for name, df in {"Partidos.xlsx": partidos_df, "Usuarios.xlsx": usuarios_df, "Pronosticos.xlsx": pron_df}.items():
        b = BytesIO()
        with pd.ExcelWriter(b, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        st.download_button(f"Descargar {name}", b.getvalue(), file_name=name)

    st.warning("Zona peligrosa")
    confirm1 = st.checkbox("Confirmo que quiero reiniciar el torneo")
    confirm2 = st.text_input("Escribe REINICIAR")
    if st.button("Reiniciar Torneo") and confirm1 and confirm2 == "REINICIAR":
        from database import engine
        from models import Base
        Base.metadata.drop_all(engine)
        Base.metadata.create_all(engine)
        st.success("Torneo reiniciado")
