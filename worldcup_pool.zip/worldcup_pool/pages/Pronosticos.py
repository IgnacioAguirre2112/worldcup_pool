from datetime import datetime
import streamlit as st
from sqlalchemy import select
from database import SessionLocal, guardar_pronostico, bonus_bloqueado
from models import Partido, Pronostico, PronosticoBonus

st.set_page_config(page_title="Pronósticos", page_icon="📝", layout="wide")
st.title("📝 Pronósticos")

usuario_id = st.session_state.get("usuario_id")
if not usuario_id:
    st.warning("Primero ingresa tu nombre en la página principal.")
    st.stop()

with SessionLocal() as db:
    partidos = db.scalars(select(Partido).order_by(Partido.fecha_hora_utc)).all()

if not partidos:
    st.info("Aún no hay fixture cargado.")

for partido in partidos:
    cerrado = datetime.utcnow() >= partido.fecha_hora_utc
    with st.container(border=True):
        st.subheader(f"{partido.equipo_local} vs {partido.equipo_visita}")
        st.caption(f"{partido.fase} · {partido.fecha_hora_utc:%Y-%m-%d %H:%M} UTC")
        with SessionLocal() as db:
            existente = db.scalar(select(Pronostico).where(Pronostico.usuario_id == usuario_id, Pronostico.partido_id == partido.id))
        col1, col2, col3 = st.columns([1, 1, 2])
        gl = col1.number_input(f"Goles {partido.equipo_local}", 0, 20, value=existente.goles_local_pronosticado if existente else 0, disabled=cerrado, key=f"gl_{partido.id}")
        gv = col2.number_input(f"Goles {partido.equipo_visita}", 0, 20, value=existente.goles_visita_pronosticado if existente else 0, disabled=cerrado, key=f"gv_{partido.id}")
        if cerrado:
            col3.warning("Pronóstico cerrado")
        elif col3.button("Guardar pronóstico", key=f"save_{partido.id}"):
            try:
                guardar_pronostico(usuario_id, partido.id, int(gl), int(gv))
                st.success("Pronóstico guardado")
            except Exception as e:
                st.error(str(e))

st.divider()
st.subheader("Bonus")
if bonus_bloqueado():
    st.warning("Pronósticos bonus cerrados")
else:
    with SessionLocal() as db:
        bonus = db.get(PronosticoBonus, usuario_id)
    campeon = st.text_input("Campeón", value=bonus.campeon if bonus else "")
    subcampeon = st.text_input("Subcampeón", value=bonus.subcampeon if bonus else "")
    tercer = st.text_input("Tercer lugar", value=bonus.tercer_lugar if bonus else "")
    goleador = st.text_input("Goleador", value=bonus.goleador if bonus else "")
    if st.button("Guardar bonus"):
        with SessionLocal() as db:
            b = db.get(PronosticoBonus, usuario_id) or PronosticoBonus(usuario_id=usuario_id)
            b.campeon, b.subcampeon, b.tercer_lugar, b.goleador = campeon, subcampeon, tercer, goleador
            db.merge(b)
            db.commit()
        st.success("Bonus guardado")
