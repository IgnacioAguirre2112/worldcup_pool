from datetime import datetime
import streamlit as st
from sqlalchemy import select, func
from database import SessionLocal, init_db, get_or_create_user, ranking_dataframe
from models import Partido, Usuario

st.set_page_config(page_title="Mundial 2026", page_icon="⚽", layout="wide")
init_db()

st.title("⚽ Mundial FIFA 2026")
st.caption("Pronósticos, ranking y estadísticas en tiempo real")

with st.sidebar:
    st.header("Ingreso")
    nombre = st.text_input("Tu nombre", value=st.session_state.get("nombre", ""), max_chars=80)
    if st.button("Entrar") and nombre.strip():
        try:
            user = get_or_create_user(nombre)
            st.session_state["usuario_id"] = user.id
            st.session_state["nombre"] = user.nombre
            st.success(f"Sesión iniciada: {user.nombre}")
        except Exception as e:
            st.error(str(e))

if "usuario_id" not in st.session_state:
    st.info("Ingresa tu nombre en la barra lateral para participar.")

with SessionLocal() as db:
    total_participantes = db.scalar(select(func.count(Usuario.id))) or 0
    total_partidos = db.scalar(select(func.count(Partido.id))) or 0
    jugados = db.scalar(select(func.count(Partido.id)).where(Partido.resultado_oficial_cargado == True)) or 0
    pendientes = total_partidos - jugados
    proximo = db.scalars(select(Partido).where(Partido.fecha_hora_utc > datetime.utcnow()).order_by(Partido.fecha_hora_utc).limit(1)).first()

ranking = ranking_dataframe()
lider = ranking.iloc[0]["Participante"] if not ranking.empty else "-"

c1, c2, c3, c4, c5, c6 = st.columns(6)
c1.metric("Participantes", total_participantes)
c2.metric("Partidos", total_partidos)
c3.metric("Jugados", jugados)
c4.metric("Pendientes", pendientes)
c5.metric("Líder", lider)
c6.metric("Próximo partido", f"{proximo.equipo_local} vs {proximo.equipo_visita}" if proximo else "-")

st.subheader("Ranking General")
if ranking.empty:
    st.warning("Aún no hay participantes o puntajes.")
else:
    st.dataframe(ranking, hide_index=True, use_container_width=True)
